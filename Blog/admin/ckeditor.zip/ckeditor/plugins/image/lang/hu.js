/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'hu', {
	alt: 'Alternatív szöveg',
	border: 'Keret',
	btnUpload: 'Küldés a szerverre',
	button2Img: 'A kiválasztott képgombból sima képet szeretne csinálni?',
	hSpace: 'Vízsz. táv',
	img2Button: 'A kiválasztott képből képgombot szeretne csinálni?',
	infoTab: 'Alaptulajdonságok',
	linkTab: 'Hivatkozás',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	resetSize: 'Eredeti méret',
	title: 'Kép tulajdonságai',
	titleButton: 'Képgomb tulajdonságai',
	upload: 'Feltöltés',
	urlMissing: 'Hiányzik a kép URL-je',
	vSpace: 'Függ. táv',
	validateBorder: 'A keret méretének egész számot kell beírni!',
	validateHSpace: 'Vízszintes távolságnak egész számot kell beírni!',
	validateVSpace: 'Függőleges távolságnak egész számot kell beírni!'
} );
